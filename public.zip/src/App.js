import "./App.css";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Product from "./Component/Mainpage/Product";
import AllProduct from "./Component/AdminDashboard/AllProduct";


function App() {
  return (
    <div>
      <Router>
        <Routes>
       
          <Route exact path="/" element={<Product />}></Route>
          
          <Route exact path="/Product" element={<AllProduct/>}></Route>
        
        
        </Routes>
      </Router>
    </div>
  );
}

export default App;
