
//create connection
const mysql = require("mysql");
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'kids'
});
//connect to database
conn.connect((err) => {
    if (err) throw err;
    console.log('Mysql Connected...');
});