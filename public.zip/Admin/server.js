const express = require("express");
const http = require("http");
const socketIO = require("socket.io");
require("../Admin/config.js");
const cors = require("cors");
const app = express();
const server = http.createServer(app);
const io = socketIO(server);
app.use(cors());

//route for products
// get all product
app.get("/products", (req, res) => {
  let sql = "SELECT * FROM products";
  let query = conn.query(sql, (err, results) => {
    if (err) {
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      res.json(results);
    }
  });
});


//route for delete product
app.delete('/productdelete/:id',function(req,res){
  const id=req.params.id;
  console.log(id);
  
  let sql ="DELETE FROM products WHERE id="+id;
  let query =conn.query(sql, (err,results)=>{
    if (err) {
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
      });
});

// Update Product API endpoint
app.put("/productsupdate/:id", (req, res) => {
  const productId = req.params.id;
  const { name, price } = req.body;

  if (!name || !price) {
    return res
      .status(400)
      .json({ error: "Invalid or missing name or price value." });
  }

  const updateQuery =  "UPDATE products SET name=?, price=? WHERE id=?";

  db.query(updateQuery, [name, price, productId], (error, result) => {
    if (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      if (result.affectedRows > 0) {
        // Emit a real-time update to connected clients
        io.emit("productUpdated", { id: productId, name, price });

        res.json({ success: true, message: "Product updated successfully" });
      } else {
        res.status(404).json({ error: "Product not found" });
      }
    }
  });
});

// Socket.IO Connection
io.on("connection", (socket) => {
  console.log("A user connected");

  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
});

const PORT = process.env.PORT || 3305;

server.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
